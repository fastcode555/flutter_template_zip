const Map<String, Map<String, String>> localizedSimpleValues = {
  // 'zh-Hans_CN': languageZhHans,
  // 'en_US': languageEn,
  // 'zh-Hant_HK': languageZhHant,
};

///获取资源
class Ids {
  static const String cancel = 'cancel';
}
