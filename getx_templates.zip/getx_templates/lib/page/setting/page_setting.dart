import 'package:flutter/material.dart';
import 'package:%s/page/setting/page_language.dart';
import 'package:%s/widgets/custom_scaffold.dart';
import 'package:%s/widgets/listtitle_ex.dart';
import 'package:%s/widgets/switch_title_ex.dart';
import 'package:infinity_core/core.dart';

class PageSetting extends StatelessWidget {
  static const String routeName = "/setting/PageSetting";

  const PageSetting({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return CustomScaffold(
      automaticallyImplyLeading: false,
      lable: "设置",
      body: Column(
        children: [
          ListTitleEx(
            "语言",
            onTap: () => NavigatorUtil.pushName(PageLanguage.routeName),
          ),
          SwitchTitleEx(
            "语言",
            onChanged: (value) {},
          ),
        ],
      ),
    );
  }
}
