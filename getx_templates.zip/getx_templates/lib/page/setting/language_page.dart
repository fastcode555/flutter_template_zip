import 'package:flutter/material.dart';
import 'package:%s/widgets/custom_scaffold.dart';
import 'package:infinity_core/core.dart';
import 'package:infinity_core/model/language_model.dart';

class LanguagePage extends StatelessWidget {
  static const String routeName = "/page/PageLanguage";

  const LanguagePage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return CustomScaffold(
      lable: '语言',
      body: _PageListWidget(),
    );
  }
}

class _PageListWidget extends StatefulWidget {
  @override
  __PageListWidgetState createState() => __PageListWidgetState();
}

class __PageListWidgetState extends State<_PageListWidget> {
  LanguageModel _groupValue = LanguageUtil.getCurrentLanguage();

  @override
  Widget build(BuildContext context) {
    return Column(
      children: Global.languages.mapWidget((index, t) {
        return _RadioListTitle(
          t.isSystem() ? t.titleId.tr : t.titleId,
          value: t,
          groupValue: _groupValue,
          onChanged: (language) {
            setState(
              () {
                _groupValue = language!;
              },
            );
            LanguageUtil.setLocalModel(language!);
          },
        );
      }),
    );
  }
}

class _RadioListTitle extends StatelessWidget {
  final String title;
  final LanguageModel value;
  final LanguageModel groupValue;
  final ValueChanged<LanguageModel?>? onChanged;

  const _RadioListTitle(
    this.title, {
    required this.value,
    required this.groupValue,
    required this.onChanged,
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () => onChanged?.call(value),
      child: Container(
        height: 50,
        padding: const EdgeInsets.symmetric(horizontal: 20),
        child: Row(
          children: [
            Text(title, style: const TextStyle(fontSize: 18)),
            const Spacer(),
            Radio(
              value: value,
              groupValue: groupValue,
              onChanged: onChanged,
            ),
          ],
        ),
      ),
    );
  }
}
