import 'package:flutter/material.dart';
import 'package:%s/main_page.dart';
import 'package:%s/res/index.dart';
import 'package:%s/widgets/custom_scaffold.dart';

class PageSplash extends BaseUnView {
  static const String routeName = "/page/PageSplash";

  @override
  void onReady() {
    super.onReady();
    Future.delayed(const Duration(milliseconds: 1000), () {
      NavigatorUtil.pushReplacementNamed(MainPage.routeName);
    });
  }

  @override
  Widget build(BuildContext context) {
    return CustomScaffold(
      showAppBar: false,
      body: SizedBox(
        width: Get.width,
        child: Column(
          children: const [
            Spacer(flex: 2),
            //Image.asset('' /*TranslationService*/, width: 100, height: 100),
            Icon(Icons.car_crash, size: 100),
            Spacer(flex: 3),
          ],
        ),
      ),
    );
  }
}
