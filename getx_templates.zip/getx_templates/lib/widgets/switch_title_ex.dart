import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:infinity_core/core.dart';

/// @date 25/6/22
/// describe:
class SwitchTitleEx extends StatefulWidget {
  final String? asset;
  final String title;
  final bool value;
  final ValueChanged<bool>? onChanged;

  const SwitchTitleEx(
    this.title, {
    this.value = false,
    this.asset,
    this.onChanged,
    Key? key,
  }) : super(key: key);

  @override
  _SwitchTitleExState createState() => _SwitchTitleExState();
}

class _SwitchTitleExState extends State<SwitchTitleEx> {
  bool _value = false;

  @override
  void initState() {
    super.initState();
    _value = widget.value;
  }

  @override
  void didUpdateWidget(covariant SwitchTitleEx oldWidget) {
    super.didUpdateWidget(oldWidget);
    _value = widget.value;
  }

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.white,
      child: InkWell(
        onTap: () {
          setState(() => _value = !_value);
          widget.onChanged?.call(_value);
        },
        child: Container(
          height: 50,
          padding: const EdgeInsets.symmetric(horizontal: 12),
          child: Row(
            children: [
              if (!TextUtil.isEmpty(widget.asset)) Image.asset(widget.asset!, width: 25),
              const SizedBox(width: 17),
              Text(widget.title, style: const TextStyle(fontSize: 18)),
              const Spacer(),
              CupertinoSwitch(
                value: _value,
                activeColor: context.theme.primaryColor,
                onChanged: (v) {
                  setState(() => _value = v);
                  widget.onChanged?.call(_value);
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}
