import 'package:flutter/material.dart';
import 'package:infinity_core/core.dart';

class CustomScaffold extends StatelessWidget {
  final String? lable;
  final Widget? leading;
  final List<Widget>? actions;
  final bool resizeToAvoidBottomInset;
  final Widget? body;
  final bool showAppBar;
  final Color? bgColor;
  final bool automaticallyImplyLeading;

  const CustomScaffold({
    Key? key,
    this.lable,
    this.leading,
    this.actions,
    this.showAppBar = true,
    this.resizeToAvoidBottomInset = false,
    this.body,
    this.automaticallyImplyLeading = true,
    this.bgColor,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgColor,
      resizeToAvoidBottomInset: resizeToAvoidBottomInset,
      appBar: showAppBar
          ? AppBar(
              actions: actions,
              backgroundColor: Colors.white,
              automaticallyImplyLeading: automaticallyImplyLeading,
              leading: _buildLeading(context),
              elevation: 0.0,
              centerTitle: true,
              titleTextStyle: const TextStyle(fontSize: 20),
              title: Text(
                lable ?? '',
                style: const TextStyle(color: Colors.black, fontSize: 20),
              ),
            )
          : null,
      body: body,
    );
  }

  _buildLeading(BuildContext context) => automaticallyImplyLeading
      ? (leading ??
          IconButton(
            onPressed: Navigator.of(context).pop,
            icon: Icon(Icons.arrow_back_ios, color: context.theme.primaryColor),
          ))
      : null;
}
