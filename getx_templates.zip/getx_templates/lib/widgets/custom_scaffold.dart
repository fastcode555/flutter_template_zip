import 'package:flutter/material.dart';
import 'package:infinity_core/core.dart';

class CustomScaffold extends StatelessWidget {
  final String? lable;
  final Widget? leading;
  final List<Widget>? actions;
  final bool resizeToAvoidBottomInset;
  final Widget? body;
  final bool showAppBar;
  final Color? bgColor;

  const CustomScaffold({
    Key? key,
    this.lable,
    this.leading,
    this.actions,
    this.showAppBar = true,
    this.resizeToAvoidBottomInset = false,
    this.body,
    this.bgColor = Colors.black12,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgColor,
      resizeToAvoidBottomInset: resizeToAvoidBottomInset,
      appBar: showAppBar
          ? AppBar(
              actions: actions,
              backgroundColor: Colors.white,
              leading: _buildLeading(context),
              elevation: 0.0,
              centerTitle: true,
              titleTextStyle: const TextStyle(fontSize: 20),
              title: Text(lable ?? ''),
            )
          : null,
      body: body,
    );
  }

  _buildLeading(BuildContext context) =>
      leading ??
      IconButton(
        onPressed: Navigator.of(context).pop,
        icon: Icon(Icons.arrow_back_ios, color: context.theme.primaryColor),
      );
}
