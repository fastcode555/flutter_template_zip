import 'package:flutter/material.dart';
import 'package:infinity_core/core.dart';
import 'package:xdlibrary/widgets/count_down_widget.dart';
import 'package:xdlibrary/widgets/pin_button.dart';

class CountDownButton extends StatelessWidget {
  const CountDownButton({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 150,
      height: 60,
      child: CountDownWidget(builder: (status, time, countDown) {
        if (status == CountDownStatus.init) {
          return PinButton(
            title: '获取验证码',
            onPressed: countDown,
            style: TextStyle(color: Colors.white),
            decoration: BoxDecoration(color: context.theme.primaryColor),
            borderRadius: BorderRadius.circular(8),
          );
        } else {
          return PinButton(
            title: status == CountDownStatus.countDowning ? '$time s 后重新获取' : "重新获取",
            onPressed: () {
              if (status == CountDownStatus.resend) {
                countDown();
              }
            },
            style: TextStyle(color: context.theme.primaryColor),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: context.theme.primaryColor, width: 1),
            ),
          );
        }
      }),
    );
  }
}
