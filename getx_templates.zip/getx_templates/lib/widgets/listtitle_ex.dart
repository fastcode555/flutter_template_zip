import 'package:flutter/material.dart';
import 'package:infinity_core/core.dart';

/// @date 25/6/22
/// describe:
class ListTitleDivider extends StatelessWidget {
  const ListTitleDivider({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return const Padding(
      padding: EdgeInsets.only(left: 40, right: 14),
      child: Divider(height: 1, thickness: 1),
    );
  }
}

class ListTitleEx extends StatelessWidget {
  final String? asset;
  final String title;
  final GestureTapCallback? onTap;

  const ListTitleEx(
    this.title, {
    this.asset,
    this.onTap,
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.white,
      child: InkWell(
        onTap: onTap,
        child: Container(
          height: 50,
          padding: const EdgeInsets.symmetric(horizontal: 12),
          child: Row(
            children: [
              if (!TextUtil.isEmpty(asset)) Image.asset(asset!, width: 25),
              const SizedBox(width: 17),
              Text(title, style: const TextStyle(fontSize: 18)),
              const Spacer(),
              const Icon(Icons.keyboard_arrow_right, size: 30),
            ],
          ),
        ),
      ),
    );
  }
}
