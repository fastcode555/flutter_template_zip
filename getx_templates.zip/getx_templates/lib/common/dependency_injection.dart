import 'package:%s/api/api_service.dart';
import 'package:%s/api/apis.dart';
import 'package:%s/api/http_manager.dart';
import 'package:%s/common/config/app_image_config.dart';
import 'package:%s/common/config/app_ui_config.dart';
import 'package:infinity_core/core.dart';

class DependencyInjection {
  static Future<void> init() async {
    Apis.init();
    HttpManager.init(CustomHttpManager());
    ImageLoader.init(AppImageConfig());
    AppUI.init(AppUiConfig());
    Get.put(ApiService());
  }
}
