import 'package:infinity_core/net/base_repository.dart';

class ApiService extends BaseRepository {}
