import 'package:%s/api/server_env.dart';
import 'package:infinity_core/core.dart';
import 'package:infinity_core/global/core_config.dart';

const String _hostTestKey = "host_test_key";

class Apis {
  static const String host = "https://api.gorden.club/app/";
  static const String hostTest = "https://api-dev.gorden.club/app/";
  static const String hostPrepare = "https://api-seed-resources.com/app/";

  static String _host = host;
  static ServerEnv server = ServerEnvRaw.fromEnvironment();

  static String resolveHost() => _host;

  static void init() async {
    if (CoreConfig.DEBUG) {
      final host = SpUtil.getString(_hostTestKey);
      server = ServerEnvRaw.fromEnvironment(defaultValue: ServerEnvs.parseFrom(host));
      _host = server.host;
    } else {
      server = ServerEnv.production;
      _host = server.host;
    }
  }

  static Future switchHost(String? newHost) async {
    _host = newHost ?? _host;
    server = ServerEnvs.parseFrom(newHost);
    await SpUtil.putString(_hostTestKey, _host);
  }
}
