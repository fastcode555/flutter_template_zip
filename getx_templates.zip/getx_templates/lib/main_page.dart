import 'dart:io';

import 'package:flutter/material.dart';
import 'package:%s/res/index.dart';
import 'package:%s/widgets/custom_scaffold.dart';

class MainPage extends StatefulWidget {
  static const String routeName = "/ui/MainPage";

  const MainPage({Key? key}) : super(key: key);

  @override
  _MainPageState createState() => _MainPageState();
}

class _MainPageState extends State<MainPage> {
  int _currentIndex = 0;

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async {
        InfinityCore.backToDesktop();
        return !Platform.isAndroid;
      },
      child: _buildBody(),
    );
  }

  _buildBody() {
    return CustomScaffold(
      resizeToAvoidBottomInset: false,
      showAppBar: false,
      body: Column(
        children: [
          Expanded(
            child: LazyIndexedStack(
              index: _currentIndex,
              preLoadIndex: 1,
              // 购物车在App启动即加载
              itemBuilder: (context, index) {
                switch (index) {
                  case 0:
                    return Text("0" * 100);
                  case 1:
                    return Text("1" * 100);
                  case 2:
                    return Text("2" * 100);
                }
                return const Text("2");
              },
              itemCount: 3,
            ),
          ),
          _buildBottomBar(context),
        ],
      ),
    );
  }

  _buildBottomBar(BuildContext context) {
    return Align(
      alignment: Alignment.bottomCenter,
      child: BottomNavigationBar(
        items: [
          _buildItem("R.icPeople", "R.icPeopleActive", "学生"),
          _buildItem("R.icEducation", "R.icEducationActive", "课堂"),
          _buildItem("R.icMoney", "R.icMoneyActive", "订单"),
          //_buildItem(R.icMoney, "订单"),
        ],
        showSelectedLabels: true,
        showUnselectedLabels: true,
        selectedItemColor: context.theme.primaryColor,
        iconSize: 24,
        currentIndex: _currentIndex,
        elevation: 20,
        onTap: _handlePageChange,
      ),
    );
  }

  _buildItem(String assetName, String assetActive, String title) {
    return BottomNavigationBarItem(
      label: title,
      icon: Image.asset(assetName, width: 24),
      activeIcon: Image.asset(assetActive, width: 24),
    );
  }

  _handlePageChange(int index) {
    setState(() {
      _currentIndex = index;
    });
  }
}
