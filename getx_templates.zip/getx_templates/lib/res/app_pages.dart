import 'package:%s/debug_page.dart';
import 'package:%s/main_page.dart';
import 'package:%s/page/page_splash.dart';
import 'package:infinity_core/common/transparent_rounter.dart';
import 'package:infinity_core/core.dart';

class AppPages {
  static const INITIAL = PageSplash.routeName;
  static final List<GetPage> routes = [
    _page(
      name: DebugPage.routeName,
      page: () => const DebugPage(),
    ),
    _page(
      name: MainPage.routeName,
      page: () => const MainPage(),
    ),
    _page(
      name: PageSplash.routeName,
      page: () => const PageSplash(),
    ),
  ];

  static final unknownRoute = _page(
    name: MainPage.routeName,
    page: () => const MainPage(),
  );

  static GetPage _page({
    required String name,
    required GetPageBuilder page,
    bool transparentRoute = false,
    Bindings? binding,
    Transition? transition,
    CustomTransition? customTransition,
    bool hideMusicBar = false,
    bool hideBottomBar = true,
  }) {
    if (transparentRoute) {
      return TransparentRoute(
        name: name,
        binding: binding,
        transition: transition ?? Transition.downToUp,
        page: () {
          Monitor.instance.putPage(name);
          return page();
        },
      );
    }

    return GetPage(
      name: name,
      binding: binding,
      customTransition: customTransition,
      transition: transition ?? Transition.rightToLeft,
      page: () {
        Monitor.instance.putPage(name);
        return page();
      },
    );
  }
}
