import 'package:%s/debug_page.dart';
import 'package:%s/main_page.dart';
import 'package:%s/page/setting/language_page.dart';
import 'package:%s/page/setting/setting_page.dart';
import 'package:%s/page/splash_page.dart';
import 'package:infinity_core/core.dart';

class AppPages {
  static const initial = SplashPage.routeName;
  static final List<GetPage> routes = [
    _page(
      name: DebugPage.routeName,
      page: () => const DebugPage(),
    ),
    _page(
      name: SettingPage.routeName,
      page: () => SettingPage(),
    ),
    _page(
      name: LanguagePage.routeName,
      page: () => const LanguagePage(),
    ),
    _page(
      name: MainPage.routeName,
      page: () => const MainPage(),
    ),
    _page(
      name: SplashPage.routeName,
      page: () => SplashPage(),
    ),
  ];

  static final unknownRoute = _page(
    name: MainPage.routeName,
    page: () => const MainPage(),
  );

  static GetPage _page({
    required String name,
    required GetPageBuilder page,
    bool transparentRoute = false,
    Bindings? binding,
    Transition? transition,
    CustomTransition? customTransition,
  }) {
    if (transparentRoute) {
      return TransparentRoute(
        name: name,
        binding: binding,
        transition: transition ?? Transition.downToUp,
        page: () {
          Monitor.instance.putPage(name);
          return page();
        },
      );
    }

    return GetPage(
      name: name,
      binding: binding,
      customTransition: customTransition,
      transition: transition ?? Transition.rightToLeft,
      page: () {
        Monitor.instance.putPage(name);
        return page();
      },
    );
  }
}
