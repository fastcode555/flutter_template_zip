import 'package:flutter/material.dart';

class Colours {
  static const Color mainColor = Color(0xff2099ff);
  static const Color mainTextColor = Color(0xff242E28);
  static const Color hintTextColor = Color(0xff949494);
  static const Color bgColor = Color(0xffF8F8F8);
}
