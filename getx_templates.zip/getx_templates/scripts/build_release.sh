#! /bin/bash

startTime=$(date +%Y%m%d-%H:%M:%S)
startTime_s=$(date +%s)

sh core/build.sh release 狗蛋日记 release true scripts/core/ExportOptions.plist true

endTime=$(date +%Y%m%d-%H:%M:%S)
endTime_s=$(date +%s)
sumTime=$(($endTime_s - $startTime_s))
echo "$startTime ---> $endTime" "总耗费时长:$sumTime s"