#! /bin/bash
sh core/build.sh release 狗蛋日记 scripts/core/ExportOptions.plist