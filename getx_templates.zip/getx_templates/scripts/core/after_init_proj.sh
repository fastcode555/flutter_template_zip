#! /bin/bash
cd scripts/core/
rm -rf ios/ ios.sh android.sh macos.sh after_init_proj.sh