#! /bin/bash
#创建多语言文件夹
function writeLanguageEn() {
  if [ ! -d en.lproj ]; then
    mkdir en.lproj
    file="en.lproj/InfoPlist.strings"
    appName=$1
    echo "\"CFBundleName\" = \"$appName\";" >>$file
    echo "\"NSCameraUsageDescription\" = \"Used for user to set avatar or feedback picture\";" >>$file
    echo "\"NSPhotoLibraryUsageDescription\" = \"Used for user to set avatar or feedback picture\";" >>$file
    echo "\"NSMicrophoneUsageDescription\" = \"Used to capture audio for the image selector plugin\";" >>$file
  fi
}
function writeLanguageZhHans() {
  if [ ! -d zh-Hans.lproj ]; then
    mkdir zh-Hans.lproj
    file="zh-Hans.lproj/InfoPlist.strings"
    appName=$1
    echo "\"CFBundleName\" = \"$appName\";" >>$file
    echo "\"NSCameraUsageDescription\" = \"用于用户设置头像或反馈图片\";" >>$file
    echo "\"NSPhotoLibraryUsageDescription\" = \"用于用户设置头像或反馈图片\";" >>$file
    echo "\"NSMicrophoneUsageDescription\" = \"用于为图像选择器插件捕获音频\";" >>$file
  fi
}
function writeLanguageZhHant() {
  if [ ! -d zh-Hant.lproj ]; then
    mkdir zh-Hant.lproj
    file="zh-Hant.lproj/InfoPlist.strings"
    appName=$1
    echo "\"CFBundleName\" = \"$appName\";" >>$file
    echo "\"NSCameraUsageDescription\" = \"用於用戶設置頭像或反饋圖片\";" >>$file
    echo "\"NSPhotoLibraryUsageDescription\" = \"用於用戶設置頭像或反饋圖片\";" >>$file
    echo "\"NSMicrophoneUsageDescription\" = \"用於為圖像選擇器插件捕獲音頻\";" >>$file
  fi
}

appName=$1
#将共用的配置复制ios下面
cp -r scripts/core/ios/Runner.entitlements ios/Runner/
#写入英语多语言文件
writeLanguageEn $appName
#写入简体中文
writeLanguageZhHans $appName
#写入繁体中文
writeLanguageZhHant $appName

iosConfig=$(
  cat <<-EOF
	<key>ITSAppUsesNonExemptEncryption</key>
  <false/>
  <key>NSAppTransportSecurity</key>
  <dict>
      <key>NSAllowsArbitraryLoads</key>
      <true/>
      <key>NSAllowsArbitraryLoadsForMedia</key>
      <true/>
  </dict>
EOF
)