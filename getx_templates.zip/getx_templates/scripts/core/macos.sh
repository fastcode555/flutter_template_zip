#! /bin/bash
function addPropForInfo() {
  content=$(cat $2)
  content=$(echo "${content}" | sed 's/<\/dict>//g')
  content=$(echo "${content}" | sed 's/<\/plist>//g')
  echo "${content}${1}" >$2
}

appName=$1
cd macos/Runner/

# 为ios增加算法权限，设为false，设置可以访问网络
macosConfig=$(
  cat <<-EOF

    <key>ITSAppUsesNonExemptEncryption</key>
    <false/>
    <key>NSAppTransportSecurity</key>
    <dict>
        <key>NSAllowsArbitraryLoads</key>
        <true/>
        <key>NSAllowsArbitraryLoadsForMedia</key>
        <true/>
    </dict>
</dict>
</plist>
EOF
)
macosDebugProp=$(
  cat <<-EOF

    <key>com.apple.security.network.client</key>
    <true/>
</dict>
</plist>
EOF
)

addPropForInfo $macosConfig Info.plist
addPropForInfo $macosDebugProp DebugProfile.entitlements

cd ../../
