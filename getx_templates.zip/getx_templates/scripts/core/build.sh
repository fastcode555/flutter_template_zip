#! /bin/bash
# 完全不需要依赖gradle 配置信息的打包脚本
# $1 打包方式； $2希望打包的前缀名 $3 ios的ExportOptions.plist的文件;

#打包方式
buildType=$1

#如果有输入应用名，用输入的应用名，没输入使用工程的文件名
appName=$2

#指定ios的ExportOptions.plist 的文件路径
exportOptionsPath=$3

function printBlue() {
  echo -e "\033[34m${1}\033[0m"
}

function printResult() {
  if [ -f $1 ]; then
    printBlue "build package $2 success☀︎☀︎☀︎："
    printBlue "     $1"
  else
    printBlue "build package $2 failed⚔︎⚔︎⚔︎"
  fi
}

#获取当前文件夹
currentDir=$(basename $(pwd))
cd ..
sh $currentDir/refresh.sh
cd $currentDir

#获取应用名,通过脚本获取当前应用目录的名字，作为打包的应用名
if [ ! $appName ]; then
  currentDir=$(basename $(pwd))
  cd ..
  appName=$(basename $(pwd))
  cd $currentDir/
fi
version=$(cat ../pubspec.yaml | grep version:)
version=${version#*:*}
#去除空格
version=$(echo $version | sed 's/ //g')
#获取 versionName 和versionCode
versionName="${version%%+*}"
versionCode="${version#*+}"
#得到最后appName的名字
appName="${appName}-v${versionName}-c${versionCode}-$(date +%m%d%y)-${buildType}"
printBlue $appName

cd ..
#build android apk
flutter build apk --$buildType --target-platform android-arm64 --obfuscate --split-debug-info=$currentDir/buildPackage/AndroidDartMapping

cd build/
mkdir app_outputs
#将打包的文件复制到 app_outputs的目录下
apkFile=$(find app/outputs/apk/$buildType/*.apk)
apkFileName=$(basename $apkFile)
cp $apkFile app_outputs
cp app/outputs/apk/$buildType/output-metadata.json app_outputs
cd app_outputs
mv $apkFileName $appName.apk

#打印出apkfile的签名
keytool -printcert -jarfile $appName.apk

cd ../../

# build ios ipa
if [ ${exportOptionsPath} ]; then
  flutter build ipa --$buildType --obfuscate --split-debug-info=$currentDir/buildPackage/IosDartMapping
  xcodebuild -exportArchive -exportOptionsPlist $exportOptionsPath -archivePath build/ios/archive/Runner.xcarchive -exportPath build/app_outputs/ -allowProvisioningUpdates
fi

#显示出打包结果
cd build/app_outputs/
file=$(find *.apk)
printResult $(pwd)/$file "Android"

if [ ${exportOptionsPath} ]; then
  # 修改ios的名字
  iosfile=$(find *.ipa)
  file=$(find *.apk)
  fileName=${file%.*}
  ipaName=${iosfile%.*}
  echo "$fileName"
  mv $ipaName.ipa $fileName.ipa
  iosfile=$(find *.ipa)
  printResult $(pwd)/$iosfile "Ios"
fi
