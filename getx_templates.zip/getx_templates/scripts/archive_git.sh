#! /bin/bash
# 使用git的打包功能进行打包，请确保所有代码提交后执行此命令
cd ..
name=$(basename $(pwd))
git archive -o $name.zip HEAD