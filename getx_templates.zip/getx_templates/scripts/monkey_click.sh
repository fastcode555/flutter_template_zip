#! /bin/bash
# monkey 测试
# https://zhuanlan.zhihu.com/p/133858779
#获取当前应用的 packageName
bundleId=$(cat ../android/app/build.gradle | grep applicationId)
bundleId=$(echo $bundleId | sed 's/applicationId //g')
bundleId=$(echo $bundleId | sed 's/[\" ]*//g')

echo -e "\033[34m${bundleId}\033[0m"
#随机操作1万次
adb shell monkey -p $bundleId -v 10000
