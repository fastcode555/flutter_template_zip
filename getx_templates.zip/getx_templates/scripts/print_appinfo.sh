#! /bin/bash
# 打印app的相关信息,获取版本号，package name等
function printBlue() {
  echo -e "\033[34m${1}\033[0m"
}
function printBundleId() {
  file=$1
  if [ -f $file ]; then
    bundleId=$(cat $file | grep $2)
    if [ $bundleId ]; then
      echo "$3:"
      printBlue $bundleId
    fi
  fi
}

#获取android的包名
printBundleId ../android/app/build.gradle applicationId "Android Aplication Id"
printBundleId ../ios/Runner.xcodeproj/project.pbxproj PRODUCT_BUNDLE_IDENTIFIER "Ios Bundle Id"
printBundleId ../macos/Runner.xcodeproj/project.pbxproj PRODUCT_BUNDLE_IDENTIFIER 'Macos Bundle Id'
printBundleId ../linux/CMakeLists.txt "(APPLICATION_ID" 'Linux Application Id'

version=$(cat ../pubspec.yaml | grep version:)
version=${version#*:*}
#去除空格
version=$(echo $version | sed 's/ //g')
#获取 versionName 和versionCode
versionName="${version%%+*}"
versionCode="${version#*+}"
printBlue "VersionName:$versionName\nVersionCode:$versionCode"
