#! /bin/bash
# 初始化工程，初始化一些需要用到的文件
function writePluginsProperties() {
  if [ ! -f plugins.properties ]; then
    file='plugins.properties'
    echo plugin.rawLanguage=en >>$file
    echo plugin.languages=zh-Hans,zh-Hant,en >>$file
    echo plugin.needTranslate=true >>$file
    echo plugin.countryCode=CN,HK,US >>$file
    echo plugin.languageDir=/lib/res >>$file
  fi
}

# 为工程添加依赖
function addDependencies() {
  #在dev_dependencies中添加flutter-ume等仓库 跟flutter native splash
  flutter pub add --dev flutter_ume flutter_ume_kit_ui flutter_ume_kit_device flutter_ume_kit_perf flutter_ume_kit_show_code flutter_ume_kit_console flutter_ume_kit_dio flutter_native_splash
  #在dependencis 中添加需要的库
  flutter pub add infinity_core --git-url https://gitlab.initcapp.com/app-dev/infinity_core --git-ref develop_optimize
  flutter pub add xdlibrary
}

# 添加flutter-native-splash的配置资源
function addFlutterNativeSplash() {
  file='pubspec.yaml'
  echo '\n' >>$file
  echo 'flutter_native_splash:' >>$file
  echo '  color: "#145352"' >>$file
  echo '  background_image: assets/logo-development.png' >>$file
  echo '  image: assets/ic_launcher.png' >>$file
}

#初始化 assets的信息
function initAssets() {
  if [ ! -d assets ]; then
    mkdir assets
  fi
  sed -i "" "s/# assets:/assets:\n    - assets\//g" pubspec.yaml
}
# 将脚本工具包加入.gitignore
function addIgnoreScripts() {
  file=".gitignore"
  echo '\n' >>$file
  echo '*.sh' >>$file
  echo 'ExportOptions.plist' >>$file
}
cd ..
# 内部脚本scripts包加入.gitignore中
addIgnoreScripts
# 初始化资源文件的文件夹
initAssets
# 写入插件的配置文件
writePluginsProperties
# 添加依赖
addDependencies
# 添加flutter-native-splash需要的配置
addFlutterNativeSplash
# 注意，申请权限，ios的多语言需要打开Xcode去将多语言添加到工程中

#配置一些各个平台需要注意的点
projectName=$1
if [ ! $projectName ]; then
  projectName=$(basename $(pwd))
fi
sh scripts/core/android.sh $projectName
sh scripts/core/ios.sh $projectName
sh scripts/core/macos.sh $projectName
#执行接手后直接
sh scripts/core/after_init_proj.sh
