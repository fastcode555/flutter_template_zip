#! /bin/bash
#打包，但是不带有git的记录，删除打包脚本跟插件等配置
cd ..
flutter clean
currentDir=$(basename $(pwd))
cd ..

targetDir="$currentDir"_build_archive
mkdir $targetDir
cp -R $currentDir $targetDir
cd $targetDir/$currentDir
pwd

rm -rf .idea
rm -rf android/.idea/
rm -rf android/.gradle/
rm -rf .git
rm -rf scripts
rm -rf plugins.properties
rm -rf ios/Pods/
rm -rf macos/Pods/
rm -rf ios/.symlinks/
rm -rf macos/.symlinks/

cd ..
zip -r $currentDir.zip $currentDir/

mv $currentDir.zip ../$currentDir
cd ..
rm -rf $targetDir