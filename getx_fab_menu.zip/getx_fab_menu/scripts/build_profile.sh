#! /bin/bash
sh core/build.sh profile 狗蛋日记 scripts/core/ExportOptions.plist