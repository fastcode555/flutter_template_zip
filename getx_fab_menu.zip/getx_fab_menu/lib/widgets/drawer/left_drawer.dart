import 'package:flutter/material.dart';
import 'package:infinity_core/core.dart';
import 'package:xdlibrary/xdlibrary.dart';

/// @date 6/7/22
/// describe:
class LeftDrawer extends StatelessWidget {
  const LeftDrawer({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ListView(
      children: [
        UserAccountsDrawerHeader(
          accountEmail: Text('88783218381@gmail.com'),
          accountName: Text('我是Drawer'),
          onDetailsPressed: () {},
          currentAccountPicture: ImageLoader.circle(Test.randomImage),
        ),
        ListTile(
          title: Text('ListTile1'),
          subtitle: Text('ListSubtitle1', maxLines: 2),
          leading: ImageLoader.circle(Test.randomImage, radius: 25),
          onTap: () {
            Navigator.pop(context);
          },
        ),
        Divider(), //分割线
        new AboutListTile(
          icon: ImageLoader.circle(Test.randomImage, radius: 25),
          child: new Text("关于我们"),
          applicationName: "AppName",
          applicationVersion: CoreConfig.version,
          applicationIcon: ImageLoader.circle(Test.randomImage, radius: 25),
          applicationLegalese: CoreConfig.boundId,
          aboutBoxChildren: <Widget>[new Text("第一条..."), new Text("第二条...")],
        ),
        Divider(), //分割线
      ],
    );
  }
}
