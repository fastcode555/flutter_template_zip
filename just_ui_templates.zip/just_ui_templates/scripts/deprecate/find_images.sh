#!/bin/bash
#
#

image_dir="$1"
lib_dir="$2"

if [[ -z "$image_dir" || -z "$lib_dir" ]]; then
    echo "请指定图片目录和代码目录"
    echo "$0 app/assets/images app/lib"
    exit 0
fi

echo "图片目录: $image_dir"
echo "代码目录: $lib_dir"

find "$image_dir" -type f ! -name ".*" \
    -a ! -path "*/im_emoji/*" \
    -a ! -path "*/im_emoticons/*" |while read image_line; do
    file_name=$(basename $image_line)
    file_name=${file_name%%.*}   
    grep_num=$(grep ${file_name} $lib_dir -R |wc -l |xargs)
    # 小于 10 行才显示
    #if [[ $grep_num -le 10 ]]; then
    #    grep ${file_name} $lib_dir -R -n
    #fi
    # 没用引用的图片
    if [[ $grep_num -eq 0 ]]; then
        echo "删除 $image_line"
        rm -v "$image_line"
    fi
done

exit 0

