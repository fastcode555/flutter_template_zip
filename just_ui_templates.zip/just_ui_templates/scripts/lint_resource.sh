#! /bin/bash

#! /bin/bash
# 在工程工目录下运行 sh scripts/lint_resource.sh lib/res/r.dart lib
rFile=$1
checkDir=$2
flutter pub run check_res:check_res $rFile $checkDir