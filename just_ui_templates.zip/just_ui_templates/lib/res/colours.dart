import 'package:flutter/material.dart';

class Colours {
  static const Color mainColor = Color(0xff23be76);
  static const Color mainTextColor = Color(0xff242E28);
  static const Color hintTextColor = Color(0xff949494);
  static const Color bgColor = Color(0xffF8F8F8);
  static const Color appBarColor = Color(0xffffffff);
}
