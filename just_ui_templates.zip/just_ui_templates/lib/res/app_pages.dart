import 'package:%s/main_page.dart';
import 'package:%s/page/page_splash.dart';
import 'package:%s/page/setting/page_setting.dart';
import 'package:xdlibrary/widgets/xdlibrary_config.dart';

Map<String, WidgetBuilder> appPages = {
  PageSetting.routeName: (context) => PageSetting(),
  PageSplash.routeName: (context) => PageSplash(),
  MainPage.routeName: (context) => const MainPage(),
};
