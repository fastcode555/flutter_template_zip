import 'package:flutter/material.dart';
import 'package:%s/res/colours.dart';
import 'package:%s/widgets/custom_scaffold.dart';
import 'package:%s/widgets/listtitle_ex.dart';
import 'package:%s/widgets/switch_title_ex.dart';
import 'package:xdlibrary/widgets/poup/poup_button.dart';

class PageSetting extends StatelessWidget {
  static const String routeName = "/setting/PageSetting";

  PageSetting({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return CustomScaffold(
      automaticallyImplyLeading: false,
      actions: [
        _MorePoupButton(),
      ],
      lable: "设置",
      body: Column(
        children: [
          ListTitleEx("语言"),
          SwitchTitleEx(
            "语言",
            onChanged: (value) {},
          ),
        ],
      ),
    );
  }
}

class _MorePoupButton extends StatelessWidget {
  const _MorePoupButton({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return PoupButton<String>(
      Icon(Icons.more_vert_sharp, size: 30, color: Colours.mainColor),
      contextBuilder: () => context,
      datas: ['语言', '数学', '英语'],
      itemBuilder: (index, item) => Text(item),
      offsetBuilder: (_) => Offset(-20, 30),
      onSelected: (item) {},
    );
  }
}
