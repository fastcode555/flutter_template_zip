import 'package:flutter/material.dart';

typedef TitleBuilder<T> = String Function(T item);

class SelectField<T> extends StatefulWidget {
  final List<T>? values;
  final T? value;
  final TitleBuilder<T>? titleBuilder;
  final String? hintText;
  final ValueChanged<T?>? onChanged;
  final Decoration? decoration;
  final bool isExpanded;

  const SelectField({
    super.key,
    this.hintText,
    this.onChanged,
    this.decoration,
    required this.values,
    required this.value,
    required this.titleBuilder,
    this.isExpanded = true,
  });

  @override
  _SelectFieldState<T> createState() => _SelectFieldState<T>();
}

class _SelectFieldState<T> extends State<SelectField<T>> {
  T? _selected;

  @override
  void initState() {
    super.initState();
    _selected = widget.value;
  }

  @override
  void didUpdateWidget(covariant SelectField<T> oldWidget) {
    super.didUpdateWidget(oldWidget);
    _selected = widget.value;
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 35),
      child: Row(
        children: [
          Expanded(
            flex: 1,
            child: Text(
              widget.hintText ?? '',
              style: const TextStyle(color: Colors.black),
              textAlign: TextAlign.end,
            ),
          ),
          const SizedBox(width: 20),
          Expanded(
            flex: 2,
            child: Container(
              padding: const EdgeInsets.only(left: 8),
              height: 30,
              decoration: widget.decoration,
              child: DropdownButton<T>(
                isExpanded: widget.isExpanded,
                icon: const Icon(Icons.keyboard_arrow_down_rounded, size: 25),
                value: _selected,
                iconEnabledColor: Theme.of(context).primaryColor,
                alignment: Alignment.centerRight,
                underline: const SizedBox(),
                hint: Text(widget.hintText ?? '', style: TextStyle(color: Colors.black45)),
                items: widget.values?.map(_buildItem).toList(),
                onChanged: (value) {
                  setState(() => _selected = value);
                  widget.onChanged?.call(_selected);
                },
              ),
            ),
          ),
        ],
      ),
    );
  }

  DropdownMenuItem<T> _buildItem(T t) {
    return DropdownMenuItem(
      value: t,
      child: Text(widget.titleBuilder?.call(t) ?? '', style: TextStyle(color: Colors.black45, fontSize: 12)),
    );
  }
}
