import 'package:flutter/material.dart';
import 'package:%s/page/page_splash.dart';
import 'package:%s/res/app_pages.dart';
import 'package:%s/res/colours.dart';

void main() async {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      theme: ThemeData.light().copyWith(
        primaryColor: Colours.mainColor,
        dividerColor: Colours.bgColor,
        textSelectionTheme: const TextSelectionThemeData(
          cursorColor: Colours.mainColor,
          selectionColor: Colours.mainColor,
          selectionHandleColor: Colours.mainColor,
        ),
        splashColor: Colours.mainColor.withOpacity(0.2),
        focusColor: Colours.mainColor.withOpacity(0.2),
        hoverColor: Colours.mainColor.withOpacity(0.2),
        highlightColor: Colours.mainColor.withOpacity(0.2),
        iconTheme: const IconThemeData(color: Colours.mainColor),
      ),
      home: const PageSplash(),
      routes: appPages,
      builder: (context, widget) {
        return MediaQuery(
          //Setting font does not change with system font size
          data: MediaQuery.of(context).copyWith(textScaleFactor: 1.0),
          child: widget!,
        );
      },
    );
  }
}
