import 'package:full_getx_lib/full_getx_lib.dart';

import 'result_data.dart';

/// @date 22/7/22
/// describe: 服务端返回的最外层通用的model
mixin ResponseDecoder on GetConnect {
  ResultData asBean(Map map, [Decoder? decoder]) {
    ResultData resultData = ResultData.fromJson(map);
    try {
      if (resultData.data is Map) {
        resultData.data = decoder?.call(resultData.data) ?? resultData.data;
      } else {
        resultData.data = null;
      }
    } catch (e) {
      print(e);
    }
    return resultData;
  }

  ResultData asList<T>(Map map, [Decoder<T>? decoder]) {
    ResultData resultData = ResultData.fromJson(map);
    try {
      if (resultData.data is List) {
        List objs = resultData.data;
        List<T> datas = [];
        for (Object obj in objs) {
          T? t = decoder?.call(obj);
          if (t != null) {
            datas.add(t);
          }
        }
        resultData.data = datas;
      }
    } catch (e) {
      print(e);
    }
    return resultData;
  }
}
