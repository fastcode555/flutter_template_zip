import 'dart:convert';

import 'package:json2dart_safe/json2dart.dart';

class ResultData {
  String? msg;
  int? code;
  dynamic data;
  ApiInfo? apiInfo;
  Firebase? fireBase;
  int? runTime;
  int? msgDisplay;

  ResultData({
    this.msg,
    this.code,
    this.data,
    this.apiInfo,
    this.fireBase,
    this.runTime,
    this.msgDisplay,
  });

  Map<String, dynamic> toJson() => {
        'msg': msg,
        'code': code,
        'data': data,
        'api_info': apiInfo?.toJson(),
        'fireBase': fireBase?.toJson(),
        'runTime': runTime,
        'msg_display': msgDisplay,
      };

  ResultData.fromJson(dynamic json) {
    if (json is Map) {
      msg = json.asString('msg');
      code = json.asInt('code');
      data = json['data'];
      apiInfo = json.asBean('api_info', (v) => ApiInfo.fromJson(v));
      fireBase = json.asBean('fireBase', (v) => Firebase.fromJson(v));
      runTime = json.asInt('runTime');
      msgDisplay = json.asInt('msg_display');
    }
  }

  static ResultData toBean(dynamic) => ResultData.fromJson(json);

  @override
  String toString() => jsonEncode(toJson());
}

class ApiInfo {
  String? ip;
  String? Location;

  ApiInfo({
    this.ip,
    this.Location,
  });

  Map<String, dynamic> toJson() => {'ip': ip, 'Location': Location};

  ApiInfo.fromJson(Map json) {
    ip = json.asString('ip');
    Location = json.asString('Location');
  }

  @override
  String toString() => jsonEncode(toJson());
}

class Firebase {
  int? topic;

  Firebase({this.topic});

  Map<String, dynamic> toJson() => {'topic': topic};

  Firebase.fromJson(Map json) {
    topic = json.asInt('topic');
  }

  @override
  String toString() => jsonEncode(toJson());
}
