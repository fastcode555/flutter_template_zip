import 'package:%s/api/apis.dart';
import 'package:full_getx_lib/full_getx_lib.dart';

import 'response_decoder.dart';
import 'result_data.dart';

class ApiService extends BaseApiService with ResponseDecoder {
  static ApiService get find => Get.find();

  @override
  Map<String, dynamic>? buildCommonQuery(Map<String, dynamic>? query) {
    query ??= {};
    query['token'] = token;
    query['device_id'] = 'ew0e80830824';
    return query;
  }

  @override
  String get token => _token ?? '';
  String? _token;

  @override
  void onInit() {
    httpClient.baseUrl = Apis.host;
    httpClient.defaultDecoder = ResultData.toBean;
    //添加token
    /*httpClient.addAuthenticator<dynamic>((request) {
      request.headers['token'] = token;
      return request;
    });*/
    super.onInit();
  }
}
