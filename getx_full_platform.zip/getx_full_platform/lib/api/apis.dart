import 'package:%s/api/server_env.dart';
import 'package:full_getx_lib/full_getx_lib.dart';

const String _key = "host_test_key";

class Apis {
  static const String host = "https://api-stag.super-server5.co/api/";
  static const String hostTest = "https://api.super-server5.co/api/";
  static const String hostPrepare = "https://api-stag.super-server5.co/api/";

  static String _host = host;
  static ServerEnv server = ServerEnvRaw.fromEnvironment();

  static String resolveHost() => _host;

  static void init() async {
    if (CoreConfig.debug) {
      final host = await Gs.read(_key);
      // 优先级：环境变量 -> 本地设置 -> 默认内网
      server = ServerEnvRaw.fromEnvironment(defaultValue: ServerEnvs.parseFrom(host));
      _host = server.host;
    } else {
      server = ServerEnv.production;
      _host = server.host;
    }
  }

  static Future switchHost(String? new_host) async {
    _host = new_host ?? _host;
    server = ServerEnvs.parseFrom(new_host);
    Gs.write(_key, _host);
  }
}
