import 'dart:ui';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:%s/common/dependency_injection.dart';
import 'package:%s/page/app_pages.dart';
import 'package:%s/res/strings.dart';
import 'package:%s/res/themes.dart';
import 'package:%s/res/translation_service.dart';
import 'package:flutter_ume/flutter_ume.dart'; // UME 框架
import 'package:flutter_ume_kit_console/flutter_ume_kit_console.dart'; // debugPrint 插件包
import 'package:flutter_ume_kit_device/flutter_ume_kit_device.dart'; // 设备信息插件包
import 'package:flutter_ume_kit_perf/flutter_ume_kit_perf.dart'; // 性能插件包
import 'package:flutter_ume_kit_show_code/flutter_ume_kit_show_code.dart'; // 代码查看插件包
import 'package:flutter_ume_kit_ui/flutter_ume_kit_ui.dart'; // UI 插件包
import 'package:full_getx_lib/full_getx_lib.dart';

void main() {
  Global.init(
    () async {
      await DependencyInjection.init();
      if (kReleaseMode) {
        runApp(const MyApp());
      } else {
        PluginManager.instance
          ..register(MonitorPlugin(true))
          ..register(const WidgetInfoInspector())
          ..register(const WidgetDetailInspector())
          ..register(const ColorSucker())
          ..register(AlignRuler())
          ..register(const ColorPicker()) // 新插件
          ..register(const TouchIndicator()) // 新插件
          ..register(Performance())
          ..register(const ShowCode())
          ..register(const MemoryInfoPage())
          ..register(CpuInfoPage())
          ..register(const DeviceInfoPanel())
          ..register(Console());
        runApp(const UMEWidget(enable: true, child: MyApp())); // 初始化
      }
    },
    themeModes: [
      ThemeModel(Ids.dayMode, ThemeMode.light),
      ThemeModel(Ids.nightMode, ThemeMode.dark),
      ThemeModel(Ids.followTheSystem, ThemeMode.system),
    ],
  );
}

class MyApp extends BaseUnView {
  const MyApp({Key? key}) : super(key: key);

  @override
  void onInit() {
    super.onInit();
    Monitor.instance.addAction(
      const MonitorActionWidget(title: "DebugPage"),
    );
  }

  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      debugShowCheckedModeBanner: false,
      scrollBehavior: MyCustomScrollBehavior(),
      enableLog: kDebugMode,
      initialRoute: AppPages.initial,
      getPages: AppPages.routes,
      defaultTransition: Transition.cupertino,
      unknownRoute: AppPages.unknownRoute,
      locale: LanguageUtil.initLanguage().toLocale(),
      theme: Themes.theme(),
      darkTheme: Themes.theme(true),
      translations: TranslationService(),
    );
  }
}

class MyCustomScrollBehavior extends MaterialScrollBehavior {
  @override
  Set<PointerDeviceKind> get dragDevices => {...super.dragDevices, PointerDeviceKind.mouse};
}
