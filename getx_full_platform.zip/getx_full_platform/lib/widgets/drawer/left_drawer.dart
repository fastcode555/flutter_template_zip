import 'package:flutter/material.dart';
import 'package:xdlibrary/xdlibrary.dart';

class LeftDrawer extends StatelessWidget {
  const LeftDrawer({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ListView(
      children: [
        UserAccountsDrawerHeader(
          accountEmail: const Text('88783218381@gmail.com'),
          accountName: const Text('我是Drawer'),
          onDetailsPressed: () {},
          currentAccountPicture: Image.network(Test.randomImage),
        ),
        ListTile(
          title: const Text('ListTile1'),
          subtitle: const Text('ListSubtitle1', maxLines: 2),
          leading: Image.network(Test.randomImage),
          onTap: () {
            Navigator.pop(context);
          },
        ),
      ],
    );
  }
}
