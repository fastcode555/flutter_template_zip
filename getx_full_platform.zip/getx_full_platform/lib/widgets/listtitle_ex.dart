import 'package:flutter/material.dart';
import 'package:%s/res/colours.dart';
import 'package:full_getx_lib/full_getx_lib.dart';

/// @date 25/6/22
/// describe:
class ListTitleDivider extends StatelessWidget {
  const ListTitleDivider({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return const Padding(
      padding: EdgeInsets.only(left: 40, right: 14),
      child: Divider(height: 1, thickness: 1),
    );
  }
}

class ListTitleEx extends StatelessWidget {
  final String? asset;
  final String title;
  final GestureTapCallback? onTap;

  const ListTitleEx(
    this.title, {
    this.asset,
    this.onTap,
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colours.btnColor.cr,
      child: InkWell(
        onTap: onTap,
        child: Container(
          height: 50,
          padding: const EdgeInsets.symmetric(horizontal: 12),
          child: Row(
            children: [
              if (asset.isNotNullAndEmpty) Image.asset(asset!, width: 25),
              const SizedBox(width: 17),
              Text(title, style: const TextStyle(fontSize: 18)),
              const Spacer(),
              const Icon(Icons.keyboard_arrow_right, size: 30),
            ],
          ),
        ),
      ),
    );
  }
}
