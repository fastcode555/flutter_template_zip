import 'package:%s/page/main_page.dart';
import 'package:%s/page/setting/language_page.dart';
import 'package:%s/page/setting/theme_mode_page.dart';
import 'package:full_getx_lib/full_getx_lib.dart';

class AppPages {
  static const initial = MainPage.routeName;
  static final List<GetPage> routes = [
    _page(
      name: MainPage.routeName,
      page: () => const MainPage(),
      binding: MainBinding(),
    ),
    _page(
      name: LanguagePage.routeName,
      page: () => const LanguagePage(),
      binding: LanguageBinding(),
    ),
    _page(
      binding: ThemeBinding(),
      name: ThemeModePage.routeName,
      page: () => const ThemeModePage(),
    ),
  ];

  static final unknownRoute = _page(
    name: MainPage.routeName,
    page: () => const MainPage(),
  );

  static GetPage _page({
    required String name,
    required GetPageBuilder page,
    Bindings? binding,
    Transition? transition,
    CustomTransition? customTransition,
    List<GetMiddleware>? middlewares,
  }) {
    return GetPage(
      name: name,
      binding: binding,
      customTransition: customTransition,
      middlewares: [PageMiddleware(), ...?middlewares],
      transition: transition ?? Transition.rightToLeft,
      page: page,
    );
  }
}
