import 'package:flutter/material.dart';
import 'package:%s/page/setting/language_page.dart';
import 'package:%s/page/setting/theme_mode_page.dart';
import 'package:%s/res/strings.dart';
import 'package:%s/widgets/custom_scaffold.dart';
import 'package:%s/widgets/listtitle_ex.dart';
import 'package:%s/widgets/switch_title_ex.dart';
import 'package:full_getx_lib/full_getx_lib.dart';
import 'package:xdlibrary/widgets/poup/poup_button.dart';

class SettingPage extends StatelessWidget {
  static const String routeName = "/setting/SettingPage";

  const SettingPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return CustomScaffold(
      automaticallyImplyLeading: false,
      actions: const [
        _MorePoupButton(),
      ],
      lable: Ids.setUp.tr,
      body: Column(
        children: [
          ListTitleEx(
            Ids.language.tr,
            onTap: () => Get.toNamed(LanguagePage.routeName),
          ),
          ListTitleEx(
            Ids.themeMode.tr,
            onTap: () => Get.toNamed(ThemeModePage.routeName),
          ),
          SwitchTitleEx(
            Ids.themeSwitch.tr,
            value: Get.isDarkMode,
            onChanged: (value) {},
          ),
          TextButton(onPressed: () {}, child: Text('hello')),
        ],
      ),
    );
  }
}

class _MorePoupButton extends StatelessWidget {
  const _MorePoupButton({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return PoupButton<String>(
      const Icon(Icons.more_vert_sharp, size: 30),
      contextBuilder: () => context,
      datas: const ['语言', '数学', '英语'],
      itemBuilder: (index, item) => Text(item),
      offsetBuilder: (_) => const Offset(-20, 30),
      onSelected: (item) {},
    );
  }
}
