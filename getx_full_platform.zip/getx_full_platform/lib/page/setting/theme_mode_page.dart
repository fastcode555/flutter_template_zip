import 'package:flutter/material.dart';
import 'package:%s/res/strings.dart';
import 'package:%s/widgets/custom_scaffold.dart';
import 'package:%s/widgets/radio_list_title.dart';
import 'package:full_getx_lib/full_getx_lib.dart';

class ThemeBinding implements Bindings {
  @override
  void dependencies() {
    Get.lazyPut<ThemeController>(() => ThemeController());
  }
}

class ThemeController extends BaseController {
  final theme = ThemeUtil.getCurrentTheme().obs;
}

class ThemeModePage extends BaseView<ThemeController> {
  static const String routeName = "/page/ThemeModePage";

  const ThemeModePage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return CustomScaffold(
      lable: Ids.themeMode.tr,
      body: Obx(
        () => Column(
          children: Global.themeModes.map((t) {
            return RadioListTitle<ThemeModel>(
              t.title.tr,
              value: t,
              groupValue: controller.theme.value,
              onChanged: (model) {
                controller.theme.value = model!;
                ThemeUtil.changeTheme(model);
              },
            );
          }).toList(),
        ),
      ),
    );
  }
}
