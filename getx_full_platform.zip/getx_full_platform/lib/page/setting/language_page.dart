import 'package:flutter/material.dart';
import 'package:%s/res/strings.dart';
import 'package:%s/widgets/custom_scaffold.dart';
import 'package:%s/widgets/radio_list_title.dart';
import 'package:full_getx_lib/full_getx_lib.dart';

class LanguageBinding implements Bindings {
  @override
  void dependencies() {
    Get.lazyPut<LanguageController>(() => LanguageController());
  }
}

class LanguageController extends BaseController {
  final lang = LanguageUtil.getCurrentLanguage().obs;
}

class LanguagePage extends BaseView<LanguageController> {
  static const String routeName = "/page/LanguagePage";

  const LanguagePage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return CustomScaffold(
      lable: Ids.language.tr,
      body: Obx(
        () => Column(
          children: Global.languages.map((t) {
            return RadioListTitle<LanguageModel>(
              t.isSystem() ? t.titleId.tr : t.titleId,
              value: t,
              groupValue: controller.lang.value,
              onChanged: (language) {
                controller.lang.value = language!;
                LanguageUtil.setLocalModel(language);
              },
            );
          }).toList(),
        ),
      ),
    );
  }
}
