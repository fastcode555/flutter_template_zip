import 'package:flutter/material.dart';
import 'package:%s/page/setting/setting_page.dart';
import 'package:%s/res/strings.dart';
import 'package:%s/widgets/custom_scaffold.dart';
import 'package:%s/widgets/drawer/left_drawer.dart';
import 'package:full_getx_lib/full_getx_lib.dart';
import 'package:xdlibrary/widgets/lazy_indexed_stack.dart';

class MainBinding implements Bindings {
  @override
  void dependencies() {
    Get.lazyPut<MainController>(() => MainController());
  }
}

class MainController extends BaseController {
  final index = 0.obs;
}

class MainPage extends BaseView<MainController> {
  static const String routeName = "/page/MainPage";

  const MainPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return CustomScaffold(
      resizeToAvoidBottomInset: false,
      showAppBar: false,
      drawer: const Drawer(child: LeftDrawer()),
      floatingActionButton: _buildFab(context),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,
      body: Column(
        children: [
          Expanded(
            child: Obx(
              () => LazyIndexedStack(
                index: controller.index.value,
                preLoadIndex: 1,
                // 购物车在App启动即加载
                itemBuilder: (context, index) {
                  switch (index) {
                    case 0:
                      return Text("0" * 100);
                    case 1:
                      return Text("1" * 100);
                    case 2:
                      return const SizedBox();
                    case 3:
                      return Text("3" * 100);
                    case 4:
                      return const SettingPage();
                  }
                  return const Text("2");
                },
                itemCount: 5,
              ),
            ),
          ),
          _buildBottomBar(context),
        ],
      ),
    );
  }

  _buildBottomBar(BuildContext context) {
    return Align(
      alignment: Alignment.bottomCenter,
      child: Obx(
        () => BottomNavigationBar(
          type: BottomNavigationBarType.fixed,
          items: [
            _buildItem("R.icPeople", "R.icPeopleActive", Ids.student.tr),
            _buildItem("R.icEducation", "R.icEducationActive", Ids.classroom.tr),
            const BottomNavigationBarItem(icon: SizedBox(), label: ''),
            _buildItem("R.icMoney", "R.icMoneyActive", Ids.Order.tr),
            _buildItem("R.icMoney", "R.icMoneyActive", Ids.setUp.tr),
          ],
          showSelectedLabels: true,
          showUnselectedLabels: true,
          selectedItemColor: Theme.of(context).primaryColor,
          iconSize: 24,
          currentIndex: controller.index.value,
          elevation: 20,
          onTap: (position) => controller.index.value = position,
        ),
      ),
    );
  }

  _buildItem(String assetName, String assetActive, String title) {
    return BottomNavigationBarItem(
      label: title,
      icon: const Icon(Icons.home_filled, size: 24),
      activeIcon: const Icon(Icons.home_filled, size: 24),
    );
  }

  Widget _buildFab(BuildContext context) {
    return Container(
      height: 80,
      width: 80,
      //把Container设置为圆形
      padding: const EdgeInsets.all(5),
      decoration: const BoxDecoration(
        color: Color.fromARGB(255, 250, 250, 250),
        shape: BoxShape.circle,
      ),
      child: FloatingActionButton(
        backgroundColor: Theme.of(context).primaryColor,
        onPressed: () {},
        child: const Icon(Icons.add),
      ),
    );
  }
}
