import 'package:flutter/material.dart';

import 'colours.dart';

const darkColors = {
  Colours.mainColor: Color(0xffe53e3e),
  Colours.mainTextColor: Color(0xffffffff),
  Colours.hintTextColor: Color(0xff949494),
  Colours.bgColor: Color(0xff171717),
  Colours.appBarColor: Color(0x103DFFC2),
  Colours.btnColor: Color(0xff484848),
};
