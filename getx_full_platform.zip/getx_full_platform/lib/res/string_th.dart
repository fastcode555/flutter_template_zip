import 'package:%s/res/strings.dart';

const Map<String, String> languageTh = {
  Ids.student: 'นักเรียน',
  Ids.classroom: 'ห้องเรียน',
  Ids.Order: 'คำสั่ง',
  Ids.setUp: 'ติดตั้ง',
  Ids.language: 'ภาษา',
  Ids.themeMode: 'โหมดธีม',
  Ids.themeSwitch: 'เปลี่ยนธีม',
  Ids.dayMode: 'โหมดกลางวัน',
  Ids.nightMode: 'โหมดกลางคืน',
  Ids.followTheSystem: 'ทำตามระบบ',
};
