import 'package:flutter/material.dart';
import 'package:%s/res/colours.dart';
import 'package:full_getx_lib/full_getx_lib.dart';

class Themes {
  static ThemeData theme([bool isDark = false]) {
    ThemeData _theme = isDark ? ThemeData.dark() : ThemeData.light();
    Color themeColor = Colours.mainColor.getColor(isDark);
    return _theme.copyWith(
      primaryColor: themeColor,
      primaryColorLight: themeColor,
      primaryColorDark: themeColor,
      inputDecorationTheme: InputDecorationTheme(
        focusColor: themeColor,
        focusedBorder: UnderlineInputBorder(borderSide: BorderSide(color: themeColor)),
      ),
      primaryTextTheme: TextTheme(
        headline1: TextStyle(color: Colours.mainTextColor.getColor(isDark), inherit: true),
        headline2: TextStyle(color: Colours.mainTextColor.getColor(isDark), inherit: true),
        headline3: TextStyle(color: Colours.mainTextColor.getColor(isDark), inherit: true),
        headline4: TextStyle(color: Colours.mainTextColor.getColor(isDark), inherit: true),
        headline5: TextStyle(color: Colours.mainTextColor.getColor(isDark), inherit: true),
        headline6: TextStyle(color: Colours.mainTextColor.getColor(isDark), inherit: true),
        subtitle1: TextStyle(color: Colours.mainTextColor.getColor(isDark), inherit: true),
        subtitle2: TextStyle(color: Colours.mainTextColor.getColor(isDark), inherit: true),
        bodyText1: TextStyle(color: Colours.mainTextColor.getColor(isDark), inherit: true),
        bodyText2: TextStyle(color: Colours.mainTextColor.getColor(isDark), inherit: true),
        caption: TextStyle(color: Colours.mainTextColor.getColor(isDark), inherit: true),
        button: TextStyle(color: Colours.mainTextColor.getColor(isDark), inherit: true),
        overline: TextStyle(color: Colours.mainTextColor.getColor(isDark), inherit: true),
      ),
      textButtonTheme: TextButtonThemeData(
        style: TextButton.styleFrom(
          primary: themeColor,
          textStyle: TextStyle(color: themeColor),
        ),
      ),
      iconTheme: IconThemeData(color: themeColor),
      textSelectionTheme: TextSelectionThemeData(
        selectionColor: themeColor,
        cursorColor: themeColor,
        selectionHandleColor: themeColor,
      ),
      backgroundColor: Colours.bgColor.getColor(isDark),
      splashColor: themeColor.withOpacity(0.3),
      highlightColor: themeColor.withOpacity(0.1),
      hoverColor: themeColor.withOpacity(0.1),
      platform: TargetPlatform.iOS,
      indicatorColor: themeColor,
      progressIndicatorTheme: ProgressIndicatorThemeData(
        color: themeColor,
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ButtonStyle(
          backgroundColor: MaterialStateProperty.all<Color>(themeColor),
        ),
      ),
      toggleableActiveColor: themeColor,
      appBarTheme: AppBarTheme(
        centerTitle: true,
        elevation: 0.0,
        backgroundColor: Colours.appBarColor.getColor(isDark),
        iconTheme: IconThemeData(color: themeColor),
        titleTextStyle: TextStyle(color: Colours.mainTextColor.getColor(isDark), fontSize: 20),
        toolbarTextStyle: TextStyle(color: Colours.mainTextColor.getColor(isDark)),
      ),
      /*tabBarTheme: const TabBarTheme(
        labelColor: Colors.white,
        labelStyle: TextStyles.whiteW50014,
        unselectedLabelStyle: TextStyles.whiteW50014,
        unselectedLabelColor: Colors.white,
        indicator: ResDecor.decor20,
      ),*/
    );
  }
}
