class Colours {
  static const String mainColor = '0';
  static const String mainTextColor = '1';
  static const String hintTextColor = '2';
  static const String bgColor = '3';
  static const String appBarColor = '4';
  static const String btnColor = '5';
}
