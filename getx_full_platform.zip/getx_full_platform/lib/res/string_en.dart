import 'strings.dart';

const Map<String, String> languageEn = {
  Ids.cancel: 'Cancel',
  Ids.student: 'Student',
  Ids.classroom: 'Classroom',
  Ids.Order: 'Order',
  Ids.setUp: 'Set up',
  Ids.language: 'Language',
  Ids.themeMode: 'Theme mode',
  Ids.themeSwitch: 'Theme switch',
  Ids.dayMode: 'Day mode',
  Ids.nightMode: 'Night mode',
  Ids.followTheSystem: 'Follow the system',
};
