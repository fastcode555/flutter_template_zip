///todo：这里的key是否可以开启key混淆，混淆成a,b,c这种很难去阅读的字符串
///需要修复生成的key首字为大写的问题
class Ids {
  static const String cancel = '0';
  static const String student = '1';
  static const String classroom = '2';
  static const String Order = '3';
  static const String setUp = '4';
  static const String language = '5';
  static const String themeMode = '6';
  static const String themeSwitch = '7';
  static const String dayMode = '8';
  static const String nightMode = '9';
  static const String followTheSystem = 'A';
}
