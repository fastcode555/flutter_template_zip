import 'strings.dart';

const Map<String, String> languageZhHans = {
  Ids.cancel: '取消',
	Ids.student:'学生',
	Ids.classroom:'课堂',
	Ids.Order:'订单',
	Ids.setUp:'设置',
	Ids.language:'语言',
	Ids.themeMode:'主题模式',
	Ids.themeSwitch:'主题切换',
	Ids.dayMode:'白天模式',
	Ids.nightMode:'夜晚模式',
	Ids.followTheSystem:'跟随系统',
};
