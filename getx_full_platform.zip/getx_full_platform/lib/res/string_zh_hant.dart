import 'package:%s/res/strings.dart';

const Map<String, String> languageZhHant = {
  Ids.cancel: '取消',
  Ids.student: '學生',
  Ids.classroom: '課堂',
  Ids.Order: '訂單',
  Ids.setUp: '設置',
  Ids.language: '語言',
  Ids.themeMode: '主題模式',
  Ids.themeSwitch: '主題切換',
  Ids.dayMode: '白天模式',
  Ids.nightMode: '夜晚模式',
  Ids.followTheSystem: '跟隨系統',
};
