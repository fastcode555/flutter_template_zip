import 'package:%s/api/api_service.dart';
import 'package:%s/api/apis.dart';
import 'package:%s/common/config/app_image_config.dart';
import 'package:%s/common/config/app_ui_config.dart';
import 'package:full_getx_lib/full_getx_lib.dart';

class DependencyInjection {
  static Future<void> init() async {
    Apis.init();
    ImageLoader.init(AppImageConfig());
    AppUI.init(AppUiConfig());
    Get.put(ApiService());
  }
}
