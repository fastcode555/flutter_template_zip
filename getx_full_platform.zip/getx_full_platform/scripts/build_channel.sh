#!/bin/bash
# 创建多渠道打包需要耗时统计
startTime=$(date +%Y%m%d-%H:%M:%S)
startTime_s=$(date +%s)
#定义渠道如下
#office：官方渠道，huawei:华为应用商店，xiaomi:小米应用商店,360:手机助手;wandoujia:豌豆荚，oppo:oppo应用市场，vivo:应用市场

currentDir=$(basename $(pwd))
cd ..
flutter clean
flutter pub get
cd $currentDir

for channel in {'office','huawei','xiaomi','360','wandoujia','oppo','vivo'}; do
  sh core/build.sh release 狗蛋日记 $channel
done

endTime=$(date +%Y%m%d-%H:%M:%S)
endTime_s=$(date +%s)
sumTime=$(($endTime_s - $startTime_s))
echo "$startTime ---> $endTime" "总耗费时长:$sumTime s"
