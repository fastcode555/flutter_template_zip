#! /bin/bash
appName=$1
cd macos/Runner/

# 为ios增加算法权限，设为false，设置可以访问网络
macosConfig=$(
  cat <<-EOF

    <key>ITSAppUsesNonExemptEncryption</key>
    <false/>
    <key>NSAppTransportSecurity</key>
    <dict>
        <key>NSAllowsArbitraryLoads</key>
        <true/>
        <key>NSAllowsArbitraryLoadsForMedia</key>
        <true/>
    </dict>
</dict>
</plist>
EOF
)

content=$(cat Info.plist)
content=$(echo "${content}" | sed 's/<\/dict>//g')
content=$(echo "${content}" | sed 's/<\/plist>//g')
echo "${content}${macosConfig}" >Info.plist


#修改DebugProfile.entitlements的属性
macosDebugProp=$(
  cat <<-EOF

    <key>com.apple.security.network.client</key>
    <true/>
</dict>
</plist>
EOF
)
content=$(cat DebugProfile.entitlements)
content=$(echo "${content}" | sed 's/<\/dict>//g')
content=$(echo "${content}" | sed 's/<\/plist>//g')
echo "${content}${macosDebugProp}" >DebugProfile.entitlements

cd ../../
