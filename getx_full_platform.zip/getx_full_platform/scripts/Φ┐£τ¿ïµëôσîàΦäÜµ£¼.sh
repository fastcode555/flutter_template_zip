#! /bin/bash
#Telegram 的key
TELEGRAM_KEY=2109015385:AAGUE_LfQoCIaFW2u-1kqqTgPMFiSzQCk4U
#聊天的ID
#CHAT_ID=-1001157361480
CHAT_ID=-552609753

#打包flutter的环境
FLUTTER_ENVIROMENT=/Users/infinity/Fluttersdk/flutter/bin

#发送消息的地址
TELEGRAM_URL="https://api.telegram.org/bot${TELEGRAM_KEY}/sendMessage?chat_id="

FLUTTER=$FLUTTER_ENVIROMENT/flutter

#工程路径
APP_PATH=gesound
BASE_PATH=StudioProjects/gesound/
#BASE_PATH=Code/infinity/$APP_PATH/
#打包类型
BUILD_TYPE=$1
# 打包profile或者release包
function buildProfileOrRelease() {
  echo -e "build apk ${BUILD_TYPE}"
  $FLUTTER build apk --$BUILD_TYPE --target-platform android-arm64 --obfuscate --split-debug-info=buildPackage/AndroidDartMapping
  echo -e "build ipa ${BUILD_TYPE}"
  security unlock-keychain -p abc159357 ~/Library/Keychains/login.keychain
  $FLUTTER build ipa --$BUILD_TYPE --obfuscate --split-debug-info=buildPackage/IosDartMapping
  xcodebuild -exportArchive -exportOptionsPlist buildPackage/ExportOptions.plist -archivePath build/ios/archive/Runner.xcarchive -exportPath build/app_ci/ -allowProvisioningUpdates

  cd build/app_ci
  #changed ipa name
  file=$(find *.apk)
  fileName=${file%.*}
  mv gesound.ipa $fileName.ipa

  mkdir -p ~/Public/$APP_PATH/android/$BUILD_TYPE/
  mv $file ~/Public/$APP_PATH/android/$BUILD_TYPE/
  mkdir -p ~/Public/$APP_PATH/ios/$BUILD_TYPE/
  mv $fileName.ipa ~/Public/$APP_PATH/ios/$BUILD_TYPE/

  #TELEGRAM SEND MESSAGE
  BASE_URL=http://192.168.31.200:9090
  APK_URL=$BASE_URL/$APP_PATH/android/$BUILD_TYPE/$fileName.apk
  IPA_URL=$BASE_URL/$APP_PATH/ios/$BUILD_TYPE/$fileName.ipa

  apkFile=~/Public/$APP_PATH/android/$BUILD_TYPE/$fileName.apk
  iosFile=~/Public/$APP_PATH/ios/$BUILD_TYPE/$fileName.ipa

  if [ -f $apkFile ]; then
    curl -X GET "${TELEGRAM_URL}${CHAT_ID}&text=Android:${APK_URL}"
  else
    curl -X GET "${TELEGRAM_URL}${CHAT_ID}&text=Android:build package failed:${newFileName}.apk"
  fi

  if [ -f $iosFile ]; then
    curl -X GET "${TELEGRAM_URL}${CHAT_ID}&text=IOS:${IPA_URL}"
  else
    curl -X GET "${TELEGRAM_URL}${CHAT_ID}&text=IOS:build package failed"
  fi

  echo -e 'start build super signed ipa'
  cd ../../
  pwd
}

function buildMaster() {
  echo -e 'build aab'
  $FLUTTER build appbundle --obfuscate --split-debug-info=buildPackage/BundleMapping
  cd build/app_ci
  file=$(find *.aab)
  fileName=${file%.*}
  mkdir -p ~/Public/$APP_PATH/android/bundle/
  mv $file ~/Public/$APP_PATH/android/bundle/
  #TELEGRAM SEND MESSAGE
  BASE_URL=http://192.168.31.200:9090
  APK_URL=$BASE_URL/$APP_PATH/android/bundle/$fileName.aab

  newFileName=~/Public/$APP_PATH/android/bundle/$fileName.aab
  if [ -f $newFileName ]; then
    curl -X GET "${TELEGRAM_URL}${CHAT_ID}&text=PlayStore:${APK_URL}"
  else
    curl -X GET "${TELEGRAM_URL}${CHAT_ID}&text=PlayStore:build package failed"
  fi

  cd ../../
  security unlock-keychain -p abc159357 ~/Library/Keychains/login.keychain
  $FLUTTER build ios --obfuscate --split-debug-info=buildPackage/IosDartMapping_testflight
  cd ios
  fastlane beta
  rm -rf Runner.app.*.zip
  rm -rf Runner.ipa
}

cd ~
if [ ! $BUILD_TYPE ]; then
  BUILD_TYPE=profile
fi
cd $BASE_PATH
pwd

echo "当前打包环境: $FLUTTER_ENVIROMENT"

$FLUTTER clean
git checkout -- *
git pull origin develop
$FLUTTER pub get

if [ $BUILD_TYPE = "master" ]; then
  buildMaster
else
  buildProfileOrRelease
fi