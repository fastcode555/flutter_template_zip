#!/bin/bash
# 该大小分析工具通过在构建时添加 --analyze-size 标记来调用：
cd ..
flutter clean
flutter pub get
flutter build apk --target-platform android-arm64 --analyze-size
#flutter build ios --analyze-size

# dart devtools,用命令打开DevTools,选择Open app size tool，
# 然后上传打包时生成的*-code-size-analysis_*.json的文件，可以用于资源占用的大小
# https://flutter.cn/docs/perf/app-size
