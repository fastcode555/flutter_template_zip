#!/bin/bash
currentDir=$(basename $(pwd))
echo $currentDir
flutter clean
flutter pub get
cd ..
flutter build ipa --obfuscate --split-debug-info=$currentDir/buildPackage/IosDartMapping