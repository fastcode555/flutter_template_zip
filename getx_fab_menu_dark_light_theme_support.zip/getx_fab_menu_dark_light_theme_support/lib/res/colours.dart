class Colours {
  static const String mainColor = 'mainColor';
  static const String mainTextColor = 'mainTextColor';
  static const String hintTextColor = 'hintTextColor';
  static const String bgColor = 'bgColor';
  static const String appBarColor = 'appBarColor';
  static const String btnColor = 'btnColor';
}
