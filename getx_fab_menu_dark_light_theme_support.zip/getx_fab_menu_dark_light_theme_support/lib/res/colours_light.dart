import 'package:flutter/material.dart';
import 'package:%s/res/colours.dart';

const lightColors = {
  Colours.mainColor: Color(0xff10bd43),
  Colours.mainTextColor: Color(0xff242E28),
  Colours.hintTextColor: Color(0xff949494),
  Colours.bgColor: Color(0xffffffff),
  Colours.appBarColor: Color(0xffffffff),
  Colours.btnColor: Color(0xffffffff),
};
