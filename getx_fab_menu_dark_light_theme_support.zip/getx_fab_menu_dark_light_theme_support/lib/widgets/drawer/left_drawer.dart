import 'package:flutter/material.dart';
import 'package:infinity_core/core.dart';
import 'package:xdlibrary/xdlibrary.dart';

class LeftDrawer extends StatelessWidget {
  const LeftDrawer({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ListView(
      children: [
        UserAccountsDrawerHeader(
          accountEmail: const Text('88783218381@gmail.com'),
          accountName: const Text('我是Drawer'),
          onDetailsPressed: () {},
          currentAccountPicture: ImageLoader.circle(Test.randomImage),
        ),
        ListTile(
          title: const Text('ListTile1'),
          subtitle: const Text('ListSubtitle1', maxLines: 2),
          leading: ImageLoader.circle(Test.randomImage, radius: 25),
          onTap: () {
            Navigator.pop(context);
          },
        ),
        const Divider(), //分割线
        AboutListTile(
          icon: ImageLoader.circle(Test.randomImage, radius: 25),
          applicationName: "AppName",
          applicationVersion: CoreConfig.version,
          applicationIcon: ImageLoader.circle(Test.randomImage, radius: 25),
          applicationLegalese: CoreConfig.boundId,
          aboutBoxChildren: const [Text("第一条..."), Text("第二条...")],
          child: const Text("关于我们"),
        ),
        const Divider(), //分割线
      ],
    );
  }
}
