import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:%s/res/index.dart';

Decoration _getDecoration(double? border, Color? borderColor, [BoxShape? shape]) => BoxDecoration(
      shape: shape ?? BoxShape.rectangle,
      border:
          border == null || border == 0.0 ? null : Border.all(color: borderColor ?? Colors.transparent, width: border),
      color: Colors.orange,
    );

class AppImageConfig extends ImageLoaderConfigInterface {
  @override
  LoadingErrorWidgetBuilder getErrorBuilder(double? width, double? height, double? border, Color? borderColor) {
    double? _width = (width ?? 0) > (height ?? 0) ? height : width;
    _width = ((_width ?? 0) / 3.0);
    _width = _width == 0 ? null : _width;
    return (BuildContext context, String url, _) {
      return Container(
        width: width,
        height: height,
        decoration: _getDecoration(border, borderColor),
        alignment: Alignment.center,
        child: SizedBox(
          width: _width ?? 60.w,
          height: _width ?? 60.w,
          child: Icon(Icons.garage_rounded, size: _width ?? 60.w),
        ),
      );
    };
  }

  @override
  PlaceholderWidgetBuilder getPlaceBuilder(double? width, double? height, double? border, Color? borderColor) {
    double? _width = (width ?? 0) > (height ?? 0) ? height : width;
    _width = ((_width ?? 0) / 3.0);
    _width = _width == 0 ? null : _width;
    return (BuildContext context, String url) {
      return Container(
        width: width,
        height: height,
        decoration: _getDecoration(border, borderColor),
        alignment: Alignment.center,
        child: SizedBox(
          width: _width ?? 60.w,
          height: _width ?? 60.w,
          child: Icon(Icons.garage_rounded, size: _width ?? 60.w),
        ),
      );
    };
  }

  @override
  getCircleErrorBuilder(double? radius, double? border, Color? borderColor) {
    double? _width = radius == null ? null : radius * 2 / 2.0;
    return (BuildContext context, String url, _) {
      return ClipOval(
        child: Container(
          decoration: _getDecoration(border, borderColor, BoxShape.circle),
          width: radius! * 2,
          height: radius * 2,
          alignment: Alignment.center,
          child: SizedBox(
            width: _width ?? 60.w,
            height: _width ?? 60.w,
            child: Icon(Icons.garage_rounded, size: _width ?? 60.w),
          ),
        ),
      );
    };
  }

  @override
  PlaceholderWidgetBuilder getCirclePlaceBuilder(double? radius, double? border, Color? borderColor) {
    double? _width = radius == null ? null : radius * 2 / 2.0;
    return (BuildContext context, String url) {
      return ClipOval(
        child: Container(
          decoration: _getDecoration(border, borderColor, BoxShape.circle),
          width: radius! * 2,
          height: radius * 2,
          alignment: Alignment.center,
          child: SizedBox(
            width: _width ?? 60.w,
            height: _width ?? 60.w,
            child: Icon(Icons.garage_rounded, size: _width ?? 60.w),
          ),
        ),
      );
    };
  }
}
