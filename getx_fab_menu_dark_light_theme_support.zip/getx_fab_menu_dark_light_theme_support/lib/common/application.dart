import 'package:flutter/cupertino.dart';

class Application {
  Application._internal();

  static Application? _instance;

  factory Application() => _getInstance();

  static Application get instance => _getInstance();

  final RouteObserver<ModalRoute<Object?>> routeObserver = RouteObserver<ModalRoute<Object?>>();

  static Application _getInstance() => _instance ??= Application._internal();

  String? getUid() => "";

  String? getToken() => "";

  void saveUser() {}

  void clear() {}
}
