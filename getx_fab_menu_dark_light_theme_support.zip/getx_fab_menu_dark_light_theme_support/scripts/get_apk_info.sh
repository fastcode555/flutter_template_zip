#!/bin/bash
#获取apk的 SHA-1g跟SHA-256
apkFile=$1
keytool -printcert -jarfile $apkFile