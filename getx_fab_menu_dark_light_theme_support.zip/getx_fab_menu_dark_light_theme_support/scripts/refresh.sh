#!/bin/bash
cd ..
flutter clean
flutter pub get
pwd
cd ios
pwd
pod install