#! /bin/bash
#打开安卓原生文件夹
function print() {
  echo -e "\033[34m${1}\033[0m"
}
print "1.Android"
print "2.Ios"
print "3.Macos"
read -n1 -p "选择以打开原生项目[1/2/3]? " -t 50 nativeType
if [ ! $nativeType ]; then
  nativeType=1
fi
echo -e "\n输入的内容是${nativeType}"
case $nativeType in
1)
  open -a "android Studio" ../android/
  ;;
2)
  open -a /Applications/Xcode.app ../ios/Runner.xcworkspace
  ;;
3)
  open -a /Applications/Xcode.app ../macos/Runner.xcworkspace
  ;;
*)
  echo -e "选择的模块选项暂不支持。"
  ;;
esac
